const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const mode = (process.argv[2] || 'debug').toLowerCase();
const androidDir = path.join(root, 'android');
if (!fs.existsSync(androidDir)) {
  console.error('Folder android belum ada. Jalankan: npm run android:init');
  process.exit(2);
}
const win = process.platform === 'win32';
const gradle = path.join(androidDir, win ? 'gradlew.bat' : 'gradlew');
if (!fs.existsSync(gradle)) {
  console.error('Gradle wrapper tidak ditemukan:', gradle);
  process.exit(3);
}
const task = mode === 'release' ? 'assembleRelease' : 'assembleDebug';
const result = spawnSync(gradle, [task], { cwd: androidDir, stdio: 'inherit', shell: win });
if (result.error) { console.error(result.error); process.exit(4); }
if (result.status !== 0) process.exit(result.status || 1);
const apkDir = path.join(androidDir, 'app', 'build', 'outputs', 'apk', mode);
console.log('\nBuild selesai. Periksa APK di:', apkDir);
