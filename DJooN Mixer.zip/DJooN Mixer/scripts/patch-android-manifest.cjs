const fs = require('node:fs');
const path = require('node:path');
const manifest = path.resolve(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(manifest)) {
  console.error('AndroidManifest.xml tidak ditemukan. Jalankan npm run android:init terlebih dahulu.');
  process.exit(2);
}
let xml = fs.readFileSync(manifest, 'utf8');
const permissions = [
  '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
  '<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />'
];
for (const permission of permissions) {
  if (!xml.includes(permission)) {
    const at = xml.indexOf('<application');
    if (at < 0) throw new Error('Tag <application> tidak ditemukan pada AndroidManifest.xml');
    xml = xml.slice(0, at) + permission + '\n    ' + xml.slice(at);
  }
}
fs.writeFileSync(manifest, xml);
console.log('Permission mikrofon dan audio sudah dipastikan ada pada AndroidManifest.xml');
