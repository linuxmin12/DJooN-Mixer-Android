const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const source = path.join(root, 'index.html');
const outDir = path.join(root, 'www');
if (!fs.existsSync(source)) throw new Error('index.html tidak ditemukan.');
fs.mkdirSync(outDir, { recursive: true });
fs.copyFileSync(source, path.join(outDir, 'index.html'));
console.log('Web app disiapkan di:', path.join(outDir, 'index.html'));
